#ifndef _ROS_custom_msgs_SystemUsage_h
#define _ROS_custom_msgs_SystemUsage_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "custom_msgs/Memory.h"

namespace custom_msgs
{

  class SystemUsage : public ros::Msg
  {
    public:
      typedef float _cpu_percent_type;
      _cpu_percent_type cpu_percent;
      typedef float _cpu_speed_type;
      _cpu_speed_type cpu_speed;
      typedef float _gpu_percent_type;
      _gpu_percent_type gpu_percent;
      typedef float _gpu_speed_type;
      _gpu_speed_type gpu_speed;
      typedef custom_msgs::Memory _gpu_memory_type;
      _gpu_memory_type gpu_memory;
      typedef custom_msgs::Memory _ram_type;
      _ram_type ram;
      typedef custom_msgs::Memory _disk_type;
      _disk_type disk;

    SystemUsage():
      cpu_percent(0),
      cpu_speed(0),
      gpu_percent(0),
      gpu_speed(0),
      gpu_memory(),
      ram(),
      disk()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += serializeAvrFloat64(outbuffer + offset, this->cpu_percent);
      offset += serializeAvrFloat64(outbuffer + offset, this->cpu_speed);
      offset += serializeAvrFloat64(outbuffer + offset, this->gpu_percent);
      offset += serializeAvrFloat64(outbuffer + offset, this->gpu_speed);
      offset += this->gpu_memory.serialize(outbuffer + offset);
      offset += this->ram.serialize(outbuffer + offset);
      offset += this->disk.serialize(outbuffer + offset);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->cpu_percent));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->cpu_speed));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->gpu_percent));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->gpu_speed));
      offset += this->gpu_memory.deserialize(inbuffer + offset);
      offset += this->ram.deserialize(inbuffer + offset);
      offset += this->disk.deserialize(inbuffer + offset);
     return offset;
    }

    virtual const char * getType() override { return "custom_msgs/SystemUsage"; };
    virtual const char * getMD5() override { return "615999ce700c4996d6efaba5552f2547"; };

  };

}
#endif
