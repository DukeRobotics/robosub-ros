#ifndef _ROS_custom_msgs_Memory_h
#define _ROS_custom_msgs_Memory_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace custom_msgs
{

  class Memory : public ros::Msg
  {
    public:
      typedef float _used_type;
      _used_type used;
      typedef float _total_type;
      _total_type total;
      typedef float _percentage_type;
      _percentage_type percentage;

    Memory():
      used(0),
      total(0),
      percentage(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += serializeAvrFloat64(outbuffer + offset, this->used);
      offset += serializeAvrFloat64(outbuffer + offset, this->total);
      offset += serializeAvrFloat64(outbuffer + offset, this->percentage);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->used));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->total));
      offset += deserializeAvrFloat64(inbuffer + offset, &(this->percentage));
     return offset;
    }

    virtual const char * getType() override { return "custom_msgs/Memory"; };
    virtual const char * getMD5() override { return "147888ad00173a5e7bf7fbb77ac413af"; };

  };

}
#endif
