#ifndef _ROS_custom_msgs_HydrophoneSet_h
#define _ROS_custom_msgs_HydrophoneSet_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace custom_msgs
{

  class HydrophoneSet : public ros::Msg
  {
    public:
      typedef uint32_t _type_type;
      _type_type type;
      enum { GUESS = 0 };
      enum { PROCESS = 1 };

    HydrophoneSet():
      type(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->type >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->type >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (this->type >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (this->type >> (8 * 3)) & 0xFF;
      offset += sizeof(this->type);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      this->type =  ((uint32_t) (*(inbuffer + offset)));
      this->type |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      this->type |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      this->type |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      offset += sizeof(this->type);
     return offset;
    }

    virtual const char * getType() override { return "custom_msgs/HydrophoneSet"; };
    virtual const char * getMD5() override { return "7f93a5373eeb59e63ed115c2b32dd863"; };

  };

}
#endif
