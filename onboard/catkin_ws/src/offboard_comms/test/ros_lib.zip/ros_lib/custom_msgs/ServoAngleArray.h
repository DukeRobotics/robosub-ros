#ifndef _ROS_custom_msgs_ServoAngleArray_h
#define _ROS_custom_msgs_ServoAngleArray_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace custom_msgs
{

  class ServoAngleArray : public ros::Msg
  {
    public:
      uint8_t angles[8];

    ServoAngleArray():
      angles()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      for( uint32_t i = 0; i < 8; i++){
      *(outbuffer + offset + 0) = (this->angles[i] >> (8 * 0)) & 0xFF;
      offset += sizeof(this->angles[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      for( uint32_t i = 0; i < 8; i++){
      this->angles[i] =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->angles[i]);
      }
     return offset;
    }

    virtual const char * getType() override { return "custom_msgs/ServoAngleArray"; };
    virtual const char * getMD5() override { return "cd73f724cd634c0b6f7391e0302e0d9c"; };

  };

}
#endif
